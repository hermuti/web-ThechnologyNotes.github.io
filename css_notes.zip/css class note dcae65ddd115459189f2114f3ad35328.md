# css class note

CSS is used to define styles for your web pages, including the design, layout and variations in display for different devices and screen sizes.

```jsx
body {
  background-color: lightblue;
}

h1 {
  color: white;
  text-align: center;
}

p {
  font-family: verdana;
color:red;
}
```

Inside a `footer` to add a `p` element. Then,we can nest an anchor (`a`) element in the `p` that links to `https://www.freecodecamp.org` and has the text `Visit our website`.

```jsx
<footer>
        <p>
  <a href="https://www.freecodecamp.org">Visit our website </a>
  </p>
      </footer>
```

css syntax

- `p` is a selector in CSS (it points to the HTML element you want to style: <p>).
- `color` is a property, and `red` is the property value

**css selectors**

- [Attribute selectors](https://www.w3schools.com/css/css_attribute_selectors.asp) (select elements based on an attribute or attribute value)
- [Pseudo-elements selectors](https://www.w3schools.com/css/css_pseudo_elements.asp) (select and style a part of an element)
- [Pseudo-class selectors](https://www.w3schools.com/css/css_pseudo_classes.asp) (select elements based on a certain state)
- [Combinator selectors](https://www.w3schools.com/css/css_combinators.asp) (select elements based on a specific relationship between them)
- Simple selectors (select elements based on name, id, class)

We can divide CSS selectors into five categories:

The CSS rule below will be applied to the HTML element with id="para1"; An id & class name cannot start with a number!:

```jsx
#para1 {  text-align: center;  color: red;}
```

![css 1st note.PNG](css%20class%20note%20dcae65ddd115459189f2114f3ad35328/css_1st_note.png)

padding and margin difference

css frame works

**css ways to link**

to link css externally

`<head>`

`<link rel="stylesheet" href="mystyle.css">`

`</head>`

If the internal style is defined **after** the link to the external style sheet, the <h1> elements will be how it is described in internal style. 

an inline style has the highest priority, and will override external and internal styles and browser defaults.

**css background-image**

Set the background image for a page:

```jsx

Specify that the background image should be fixed:

body {
  background-image: url("img_tree.png");
/*used to insert image at the back ground*/
  background-repeat: no-repeat;
/* Specifies an images would be repeated only horizontally or vertically,*/
  background-position: right top;
/* used to specify the position of the background image.*/
  background-attachment: fixed;
/*specifies whether the background image should scroll or be fixed*/
}
```

the image is repeated only horizontally (`background-repeat: repeat-x;`)

an image is repeated vertically, set `background-repeat: repeat-y;`

**CSS borders**

```jsx
p.dotted {border-style: dotted;}
p.dashed {border-style: dashed;}
p.solid {border-style: solid;}
p.double {border-style: double;}
p.groove {border-style: groove;}
p.ridge {border-style: ridge;}
p.inset {border-style: inset;}
p.outset {border-style: outset;}
p.none {border-style: none;}
p.hidden {border-style: hidden;}
p.mix {border-style: dotted dashed solid double;}
```

```jsx
/* 1. Selecting Elements by Tag Name */
p {
    color: #333;
    font-size: 16px;
}

/* Explanation: Selects all <p> elements and sets color to #333 and font size to 16px. */

/* 2. Selecting Elements by Class */
.button {
    background-color: #3498db;
    color: #fff;
    padding: 10px 15px;
    border-radius: 5px;
}

/* Explanation: Selects all elements with class "button" and applies styling for a button. */

/* 3. Selecting Elements by ID */
#header {
    font-size: 24px;
    text-align: center;
}

/* Explanation: Selects the element with id "header" and sets font size to 24px and text alignment to center. */

/* 4. Styling Links */
a {
    color: #2ecc71;
    text-decoration: none;
}

/* Explanation: Selects all <a> elements and sets color to #2ecc71 and removes underline decoration. */

/* Layout Properties */

/* 5. Box Model */
.box {
    width: 200px;
    height: 100px;
    padding: 10px;
    margin: 20px;
    border: 1px solid #ccc;
}

/* Explanation: Styles a box with width, height, padding, margin, and border properties. */

/* 6. Display Property */
.flex-container {
    display: flex;
    justify-content: space-between;
}

/* Explanation: Styles a flex container with items evenly spaced with space-between justification. */

/* 7. Position Property */
.position-example {
    position: relative;
    top: 10px;
    left: 20px;
}

/* Explanation: Positions an element relative to its normal position, shifted 10px down and 20px to the right. */

/* Advanced Features */

/* 8. Transitions */
.transition-example {
    width: 100px;
    height: 100px;
    background-color: #e74c3c;
    transition: background-color 0.3s ease;
}

/* Explanation: Adds a transition effect to smoothly change the background color over 0.3 seconds with ease timing function. */

/* 9. Animations */
@keyframes slide {
    from {
        margin-left: 0;
    }
    to {
        margin-left: 100px;
    }
}

.animation-example {
    animation: slide 1s ease-in-out infinite alternate;
}

/* Explanation: Defines a slide animation and applies it to an element with a 1s duration, ease-in-out timing function, infinite loop, and alternate direction. */

/* 10. Media Queries */
@media screen and (max-width: 600px) {
    /* Styles for screens with a maximum width of 600px */
    .responsive-example {
        font-size: 14px;
    }
}

/* Explanation: Applies styles specifically for screens with a maximum width of 600px using a media query. */

/* 11. Flexbox */
.flexbox-container {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

/* Explanation: Creates a flex container with items evenly spaced and centered along the main and cross axes. */

/* 12. Grid Layout */
.grid-container {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 10px;
}

/* Explanation: Sets up a grid container with three columns of equal width and a 10px gap between grid items. */

/* Responsive Design */

/* 13. Fluid Images */
img {
    max-width: 100%;
    height: auto;
}

/* Explanation: Ensures images are responsive by setting a maximum width of 100% and maintaining their aspect ratio. */

/* 14. Responsive Typography */
body {
    font-size: 16px;
}

@media screen and (min-width: 768px) {
    body {
        font-size: 18px;
    }
}

/* Explanation: Defines a responsive font size, increasing it to 18px for screens with a minimum width of 768px. */

/* 15. Responsive Navigation */
.navbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

/* Explanation: Creates a responsive navigation bar with items evenly spaced and centered using flexbox. */
```